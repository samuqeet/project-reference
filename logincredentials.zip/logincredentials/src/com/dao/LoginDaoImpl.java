package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dbutil.OracleDBConnection;
import com.exception.BusinessException;
import com.to.User;

public class LoginDaoImpl  implements LoginDao{
	
		@Override
		public boolean isValidUser(User user) throws BusinessException{
			
	
		boolean b=false;
		
		Connection connection=null;
		
		try {
			connection=OracleDBConnection.getConnection();
			String sql="select username from loginmaster where username=? and password=?";
			PreparedStatement preparedStatement=connection.prepareStatement(sql);	
			preparedStatement.setString(1,user.getUsername());
			preparedStatement.setString(2,user.getPassword());
			
			ResultSet resultset=preparedStatement.executeQuery();
			if(resultset.next())
			{
				b=true;
			}
			else
			{
				throw new BusinessException("invalid username and password");
			}
		} catch (ClassNotFoundException | SQLException  e) {
			throw new BusinessException("iNTERNAL ERROR OCCURED.....kindly contact");
			//e.printStackTrace();
		}finally {
			try {
				connection.close();
				
			}
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BusinessException("internal error occured");
			//e.printStackTrace();
		}
	}	
		return b;
		}
		
}
