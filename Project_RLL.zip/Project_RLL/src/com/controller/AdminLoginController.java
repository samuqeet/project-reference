package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.AdminDTO;
import com.service.RegistrationService;

@Controller
public class AdminLoginController {

	@Autowired
	public RegistrationService registrationService;

	@PostMapping("/adminlogin.do")
	public ModelAndView adminLogin(@RequestParam String Email, @RequestParam String login_password) {

		AdminDTO adminDTO = new AdminDTO();
		adminDTO.setEmailId(Email);
		adminDTO.setPassword(login_password);

		boolean loginAdmin = registrationService.loginAdmin(adminDTO);
		if (loginAdmin) {
			return new ModelAndView("admin_login1.html");
		} else {
			return new ModelAndView("logFail.html");
		}
	}
}
