package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.FeedbackDTO;
import com.service.RegistrationService;

@Controller
public class FeedbackController {
	
	@Autowired
	private RegistrationService registrationService;
	
	@PostMapping("/feedback.do")
	public ModelAndView feedbackcustomer(@RequestParam String Email, @RequestParam String experience, @RequestParam String comments) {
		
		FeedbackDTO feedbackDTO = new FeedbackDTO();
		
		feedbackDTO.setEmail(Email);
		feedbackDTO.setExperience(experience);
		feedbackDTO.setComments(comments);
		
		boolean feedback = registrationService.feedbacksave(feedbackDTO);
		if(feedback) {
			return new ModelAndView("thanks.html");
		}else {
			return new ModelAndView("fail.html");
		}
	}

}
