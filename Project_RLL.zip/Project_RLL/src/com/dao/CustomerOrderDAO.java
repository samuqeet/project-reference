package com.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.CustomerOrderDTO;

@Repository
public class CustomerOrderDAO {
	
	@Autowired
	private SessionFactory factory;
	
	//customer order book
	public Integer bookReserved(CustomerOrderDTO customerOrderDTO){
		Transaction transaction = null;
		Integer NoOfBookReserved = null;
		try(Session session = factory.openSession()){
			transaction = session.beginTransaction();
			NoOfBookReserved = (Integer) session.save(customerOrderDTO);
			transaction.commit();
		}catch(HibernateException e){
			transaction.commit();
			e.printStackTrace();
		}
		return NoOfBookReserved;
		
	}

}
