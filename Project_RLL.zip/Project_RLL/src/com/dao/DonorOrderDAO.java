package com.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.DonorOrderDTO;

@Repository
public class DonorOrderDAO {
	
	@Autowired
	private SessionFactory factory;
	
	//Donor order
	public Integer saveDonoOrder(DonorOrderDTO donororderDTO) {
		Transaction transaction = null;
		Integer userRegistered = null;
		
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			userRegistered = (Integer) session.save(donororderDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return userRegistered;
	}

}
