package com.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.FeedbackDTO;
@Repository
public class FeedbackDAO {
	@Autowired
	private SessionFactory factory;
	//feedback store
		public Integer feedbackSave(FeedbackDTO feedbackDTO) {
			Transaction transaction = null;
			Integer feedbacksave = null;
			
			try(Session session = factory.openSession()) {
				transaction = session.beginTransaction();
				feedbacksave = (Integer) session.save(feedbackDTO);
				transaction.commit();
			
			}catch(HibernateException e) {
				transaction.rollback();
				e.printStackTrace();
			}
			return feedbacksave;
		}

}
