package com.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.CustomerRegistrationDTO;

@Repository
public class CustomerRegistrationDAO {

	@Autowired
	private SessionFactory factory;
	
	//Registration
	public Integer saveUser(CustomerRegistrationDTO customerregistrationDTO) {
		Transaction transaction = null;
		Integer userRegistered = null;
		
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			userRegistered = (Integer) session.save(customerregistrationDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return userRegistered;
	}
	//Customer Login
	public CustomerRegistrationDTO loginUser(String Email, String Password) {
		CustomerRegistrationDTO customerregistrationDTO = null;
		String hql = "select customer from CustomerRegistrationDTO customer where customer.Email=:name1 and customer.Password=:name2";
		try (Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name1", Email);
			query.setParameter("name2", Password);
			customerregistrationDTO = (CustomerRegistrationDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return customerregistrationDTO;
	}
}
